public class TentoOne 
{
	public static void main(String args[])
	{
		//loop counter initialisation
		int i=10;

		//print statement
		System.out.println("Output is : ");

		//loop to print 1 to 10.
		while(i>=10)	
		{
			System.out.println(i);
			i--;
		}
	}
}