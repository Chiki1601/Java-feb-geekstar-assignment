import java.util.Scanner;

class SumOfDigit
{
	public static void main(String []args){
	int n,x;
int num,sum = 0;

Scanner sc = mew Scanner(System.in);
 Syatem.out.print("Enter a number: ");

n = sc.nextInt();

while(n>0)
{
	x = n%10;
	sum = sum + x;
	n = n/10 ;
	
}

Syatem.out.println("Sum of digits oa a number: "+sum);
}
}