// Java program to print
// ASCII Value of Character
public class AsciiValue {
 
    public static void main(String[] args)
    {
 
        char c = 'e';
        int ascii = c;
        System.out.println("The ASCII value of " + c + " is: " + ascii);
    }
}